import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

# 训练参数官方详解链接：https://docs.ultralytics.com/modes/train/#resuming-interrupted-trainings:~:text=a%20training%20run.-,Train%20Settings,-The%20training%20settings

if __name__ == '__main__':
    #model = YOLO('ultralytics/cfg/models/v8/yolov8n.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-LAWDS.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-C2f-EMSCP.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-C2f-EMSC.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-LSCD.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-LAWDS.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-CGRFPN.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-SPPF-LSKA.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-CGRFPN-LSCD.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool+LSCD.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-CGRFPN-LSCD+wavebackbone.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-CGRFPN-LSCD+wavebackbone+2.yaml')
    #model = YOLO('ultralytics/cfg/models/v8/yolov8-SPPF-LSKA+slimneck.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool+LSCD+AT-AFGC.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool+LSCD+cpca.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-CGRFPN+wavebackbone+2.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool1+LSCD.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool1.yaml')
    #model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool2.yaml')
    model = YOLO('ultralytics/cfg/models/v10/yolov10n-WaveletPool2+LSCD.yaml')


    # model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='dataset/my_ssdd.yaml',
                cache=False,
                imgsz=640,
                epochs=150,
                batch=16,
                #close_mosaic=0,
                close_mosaic=10,
                #workers=4,
                workers=0,
                # device='0',
                optimizer='SGD', # using SGD
                # patience=0, # close earlystop
                # resume=True, # 断点续训,YOLO初始化时选择last.pt
                # amp=False, # close amp
                # fraction=0.2,
                project='runs/train',
                name='exp',
                )